// Feasibility harness for the O200k prototype (scratch only). Modes:
//   hash <tiktokenFile>                         vocab provenance: SHA256 of the tiktoken file and of the inflated Microsoft resource
//   gencorpora <dir>                            C1-C6, W1, P1 at 1k/5k/25k/100k chars (generator copied from ../../TokInv)
//   diff <cases.tsv> <impl,...> <out> [repros]  id-sequence + count differential vs the Python oracle ids in cases.tsv
//   cpsweep <sweep.tsv> <impl> <out>            every Unicode scalar x 11 templates vs the Python oracle
//   ids <impl> <utf16hex>                       print ids (for repro verification)
//   bench <impl> <corpus> <len>                 one measurement per process: create, cold, warm, fresh (wall + CPU)
//   bpebench <kind> <bytes> <heap|scan>         BPE on ONE synthetic piece (no pre-tokenizer): wall, CPU, merges, pops
//   cancel <impl> <corpus> <len> <afterMs>      cooperative cancellation latency, measured in-process
//   unicode <ages.tsv> <out>                    .NET Unicode data vs code point ages from Python's regex module
using System.Diagnostics;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.ML.Tokenizers;
using O200k;

static class Program
{
    const string VocabPath = "/tmp/data-gym-cache/fb374d419588a4632f3f557e76b4b70aebbca790";

    static int Main(string[] args)
    {
        try
        {
            return args[0] switch
            {
                "hash" => Hash(args[1]),
                "gencorpora" => GenCorpora(args[1]),
                "diff" => Diff(args[1], args[2].Split(','), args[3], args.Length > 4 ? args[4] : null),
                "cpsweep" => CpSweep(args[1], args[2], args[3]),
                "ids" => PrintIds(args[1], args[2]),
                "bench" => Bench(args[1], args[2], int.Parse(args[3])),
                "bpebench" => BpeBench(args[1], int.Parse(args[2]), args[3]),
                "cancel" => Cancel(args[1], args[2], int.Parse(args[3]), int.Parse(args[4])),
                "unicode" => UnicodeProbe(args[1], args[2]),
                _ => throw new ArgumentException(args[0]),
            };
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERROR {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}");
            return 2;
        }
    }

    // ------------------------------------------------------------------ implementations under test
    sealed record Impl(string Name, Func<string, IReadOnlyList<int>> Ids, Func<string, int> Count);

    static RankTable? _table;
    static RankTable Table() => _table ??= LoadTable();
    static RankTable LoadTable() { using var f = File.OpenRead(VocabPath); return RankTable.Load(f); }

    static Impl MakeImpl(string name)
    {
        if (name == "ms")
        {
            var ms = MsOrdinary();
            return new Impl(name, t => ms.EncodeToIds(t), t => ms.CountTokens(t));
        }
        var c = name switch
        {
            "scan" => new O200kCounter(Table(), Segmenter.Scalar, 100),
            "scan-heap" => new O200kCounter(Table(), Segmenter.Scalar, 0),          // heap for every multi-token piece
            "scan-quad" => new O200kCounter(Table(), Segmenter.Scalar, int.MaxValue), // tiktoken scan for every piece
            "regex" => new O200kCounter(Table(), Segmenter.DotNetRegex, 100),
            _ => throw new ArgumentException("impl " + name),
        };
        return new Impl(name, t => c.EncodeToIds(t), t => c.CountTokens(t));
    }

    // Pinned Microsoft counter with NO special tokens (same construction as ../../TokInv Program.Ordinary()).
    const string MsPattern = "[^\\r\\n\\p{L}\\p{N}]?[\\p{Lu}\\p{Lt}\\p{Lm}\\p{Lo}\\p{M}]*[\\p{Ll}\\p{Lm}\\p{Lo}\\p{M}]+(?i:'s|'t|'re|'ve|'m|'ll|'d)?|[^\\r\\n\\p{L}\\p{N}]?[\\p{Lu}\\p{Lt}\\p{Lm}\\p{Lo}\\p{M}]+[\\p{Ll}\\p{Lm}\\p{Lo}\\p{M}]*(?i:'s|'t|'re|'ve|'m|'ll|'d)?|\\p{N}{1,3}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n/]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+";

    static TiktokenTokenizer MsOrdinary()
    {
        using var vocab = new DeflateStream(MsResource(), CompressionMode.Decompress);
        var pre = new RegexPreTokenizer(new Regex(MsPattern, RegexOptions.None, TimeSpan.FromMilliseconds(30000)), specialTokens: null);
        return TiktokenTokenizer.Create(vocab, pre, normalizer: null, specialTokens: null);
    }

    static Stream MsResource()
    {
        var dataAsm = Assembly.Load("Microsoft.ML.Tokenizers.Data.O200kBase");
        return dataAsm.GetManifestResourceStream("o200k_base.tiktoken.deflate")
               ?? throw new InvalidOperationException("resource not found: " + string.Join(",", dataAsm.GetManifestResourceNames()));
    }

    // ------------------------------------------------------------------ hash / provenance
    static int Hash(string tiktokenFile)
    {
        byte[] file = File.ReadAllBytes(tiktokenFile);
        Console.WriteLine($"tiktoken cache file: {tiktokenFile} bytes={file.Length} sha256={Sha(file)}");
        var dataAsm = Assembly.Load("Microsoft.ML.Tokenizers.Data.O200kBase");
        var tokAsm = typeof(Tokenizer).Assembly;
        foreach (var a in new[] { tokAsm, dataAsm })
            Console.WriteLine($"assembly {a.GetName().Name} {a.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion} file={a.Location} sha256={Sha(File.ReadAllBytes(a.Location))}");
        Console.WriteLine($"data assembly resources: {string.Join(", ", dataAsm.GetManifestResourceNames())}");
        byte[] deflated; using (var s = MsResource()) using (var m = new MemoryStream()) { s.CopyTo(m); deflated = m.ToArray(); }
        byte[] inflated; using (var d = new DeflateStream(new MemoryStream(deflated), CompressionMode.Decompress)) using (var m = new MemoryStream()) { d.CopyTo(m); inflated = m.ToArray(); }
        Console.WriteLine($"MS resource o200k_base.tiktoken.deflate: deflated bytes={deflated.Length} sha256={Sha(deflated)}");
        Console.WriteLine($"MS resource inflated: bytes={inflated.Length} sha256={Sha(inflated)} byteIdenticalToTiktokenFile={inflated.AsSpan().SequenceEqual(file)}");
        string dumpPath = Path.Combine(AppContext.BaseDirectory, "ms_o200k_inflated.bin");
        File.WriteAllBytes(dumpPath, inflated);
        Console.WriteLine($"MS inflated resource written to {dumpPath}; first 120 bytes: {Esc(Encoding.ASCII.GetString(inflated, 0, 120), 400)}");
        var sw = Stopwatch.StartNew();
        var t1 = RankTable.Load(new MemoryStream(file));
        double loadMs = sw.Elapsed.TotalMilliseconds;
        Console.WriteLine($"RankTable(tiktoken file): tokens={t1.Count} maxTokenBytes={t1.MaxTokenLength} load_ms={loadMs:F0} (ranks dense 0..{t1.Count - 1}, all 256 single bytes present: enforced by loader)");
        // Reconstruct the canonical "<base64> <rank>\n" form using the MS loader's rules (decompiled
        // TiktokenTokenizer.LoadTiktokenBpeAsync): optional "Capacity: N" first line; space-free lines get rank = line
        // number counted from the first line after the header, empty lines included.
        using var reader = new StringReader(Encoding.ASCII.GetString(inflated));
        string? line = reader.ReadLine();
        string header = line is not null && line.StartsWith("Capacity: ", StringComparison.Ordinal) ? line : "(none)";
        if (header != "(none)") line = reader.ReadLine();
        var rebuilt = new StringBuilder();
        int lineNumber = 0, tokens = 0, empty = 0;
        for (; line is not null; line = reader.ReadLine(), lineNumber++)
        {
            if (line.Length == 0) { empty++; continue; }
            if (line.Contains(' ')) throw new InvalidDataException("unexpected explicit-rank line in MS resource");
            rebuilt.Append(line).Append(' ').Append(lineNumber).Append('\n');
            tokens++;
        }
        byte[] rebuiltBytes = Encoding.ASCII.GetBytes(rebuilt.ToString());
        Console.WriteLine($"MS resource: header='{header}' tokenLines={tokens} emptyLines={empty} lineEnding={(inflated.AsSpan().IndexOf("\r\n"u8) >= 0 ? "CRLF" : "LF")}");
        Console.WriteLine($"MS resource rebuilt as '<base64> <rank>\\n': bytes={rebuiltBytes.Length} sha256={Sha(rebuiltBytes)} byteIdenticalToTiktokenFile={rebuiltBytes.AsSpan().SequenceEqual(file)}");
        var t2 = RankTable.Load(new MemoryStream(rebuiltBytes));
        Console.WriteLine($"RankTable(MS rebuilt): tokens={t2.Count} maxTokenBytes={t2.MaxTokenLength}");
        Console.WriteLine($"runtime: {RuntimeInformation.FrameworkDescription}");
        return 0;
    }

    static string Sha(byte[] b) => Convert.ToHexStringLower(SHA256.HashData(b));

    // ------------------------------------------------------------------ corpora (copied from ../../TokInv/Program.cs)
    static readonly string[] Words =
    ("the of and to in is was that for on with as by at from it this be are or an have not but which they had their his her " +
     "one all were we there been has more when will would who so if out up about into than them can only other new some could " +
     "time these two may first then do any like my now over such our man me even most made after also did many before must " +
     "through back years where much your way well down should because each just those people how too little state good very make " +
     "world still own see men work long get here between both life being under never day same another know while last might us " +
     "great old year off come since against go came right used take three himself few house use during without again place around " +
     "however home small found thought went say part once general high upon school every does got united left number course war until " +
     "always away something fact though water less public put think almost hand enough far took head yet government system better set " +
     "told nothing night end why called didn eyes find going look asked later knew point next program city business give group toward " +
     "young days let room president side social given present several order national possible rather second face per among form important " +
     "often things looked early white case john become large big need four within felt along children saw best church ever least power " +
     "development light thing seemed family interest want members mind country area others done turned although open god service certain kind problem").Split(' ');

    static readonly string[] Idents = "value item count index buffer result token offset length config request response handler context options builder writer reader stream logger cache key map list node parent child state".Split(' ');
    static readonly string[] Types = "int string var bool long double Task List<int> Span<char> IReadOnlyList<string>".Split(' ');
    const string EndOfText = "<|endoftext|>";

    static string Corpus(string kind, int len, int variant = 0)
    {
        var sb = new StringBuilder(len + 64);
        var rng = new Random(12345 + variant);
        switch (kind)
        {
            case "C1": while (sb.Length < len) sb.Append((char)rng.Next(0x4E00, 0xA000)); break;
            case "C2": sb.Append(variant == 0 ? 'a' : 'b', len); break;
            case "C3": while (sb.Length < len) sb.Append((char)('a' + rng.Next(26))); break;
            case "C4":
                while (sb.Length < len)
                {
                    int n = rng.Next(8, 21);
                    for (int i = 0; i < n; i++)
                    {
                        string w = Words[rng.Next(Words.Length)];
                        if (i == 0) w = char.ToUpperInvariant(w[0]) + w[1..];
                        sb.Append(w);
                        if (i < n - 1) sb.Append(rng.Next(9) == 0 ? ", " : " ");
                    }
                    sb.Append(rng.Next(6) == 0 ? ".\n\n" : ". ");
                }
                break;
            case "C5":
                {
                    int rot = variant == 0 ? 0 : 5;
                    var big = new StringBuilder();
                    while (big.Length < len + rot + 13) big.Append(EndOfText);
                    sb.Append(big.ToString(rot, len));
                    break;
                }
            case "C6":
                while (sb.Length < len)
                {
                    int depth = rng.Next(1, 4);
                    string ind = new string(' ', depth * 4);
                    string a = Idents[rng.Next(Idents.Length)], b = Idents[rng.Next(Idents.Length)], c = Idents[rng.Next(Idents.Length)];
                    switch (rng.Next(6))
                    {
                        case 0: sb.Append($"{ind}{Types[rng.Next(Types.Length)]} {a}{rng.Next(100)} = {b}.{char.ToUpperInvariant(c[0])}{c[1..]}({rng.Next(1000)}, \"{a}_{b}\");\n"); break;
                        case 1: sb.Append($"{ind}if ({a} != null && {b}.Length > {rng.Next(64)})\n{ind}{{\n{ind}    return {c}[{a}.Length - 1];\n{ind}}}\n"); break;
                        case 2: sb.Append($"{ind}for (int i = 0; i < {a}.Count; i++) {{ {b} += {c}[i] * 0x{rng.Next(0xFFFF):X4}; }}\n"); break;
                        case 3: sb.Append($"{ind}// TODO: {Words[rng.Next(Words.Length)]} {Words[rng.Next(Words.Length)]} {a} before {b}\n"); break;
                        case 4: sb.Append($"{ind}await {a}.WriteAsync({b}, cancellationToken).ConfigureAwait(false);\n"); break;
                        default: sb.Append($"{ind}public static {Types[rng.Next(Types.Length)]} {char.ToUpperInvariant(a[0])}{a[1..]}{rng.Next(10)}({Types[rng.Next(Types.Length)]} {b}) => {b} ?? throw new ArgumentNullException(nameof({b}));\n"); break;
                    }
                }
                break;
            case "P1": { const string punct = "!\"#$%&()*+,-./:;<=>?@[]^_`{|}~"; while (sb.Length < len) sb.Append(punct[rng.Next(punct.Length)]); break; }
            case "W1": while (sb.Length < len) sb.Append(rng.Next(2) == 0 ? ' ' : '\t'); break;
            default: throw new ArgumentException(kind);
        }
        return sb.ToString(0, len);
    }

    static int GenCorpora(string dir)
    {
        Directory.CreateDirectory(dir);
        foreach (var kind in new[] { "C1", "C2", "C3", "C4", "C5", "C6", "W1", "P1" })
            foreach (int len in new[] { 1000, 5000, 25000, 100000 })
            {
                string t = Corpus(kind, len);
                byte[] utf8 = new UTF8Encoding(false, true).GetBytes(t);
                string f = Path.Combine(dir, $"{kind}_{len}.txt");
                File.WriteAllBytes(f, utf8);
                Console.WriteLine($"{kind}_{len}\tchars={t.Length}\tutf8={utf8.Length}\tsha256={Sha(utf8)}");
            }
        return 0;
    }

    // ------------------------------------------------------------------ differential
    sealed record Case(string Id, string Cat, string Text, int[] Oracle);

    static string FromHex16(string hex) => new string(MemoryMarshal.Cast<byte, char>(Convert.FromHexString(hex)));
    static string ToHex16(string s) => Convert.ToHexStringLower(MemoryMarshal.AsBytes(s.AsSpan()));
    static int[] ParseIds(string s) => s.Length == 0 ? [] : s.Split(',').Select(int.Parse).ToArray();

    static IEnumerable<Case> ReadCases(string path)
    {
        foreach (var line in File.ReadLines(path))
        {
            var f = line.Split('\t');
            yield return new Case(f[0], f[1], FromHex16(f[2]), ParseIds(f[3]));
        }
    }

    static int Diff(string casesPath, string[] implNames, string outPath, string? reprosPath)
    {
        var impls = implNames.Select(MakeImpl).ToArray();
        var scan = implNames.Contains("scan") ? impls[Array.IndexOf(implNames, "scan")] : MakeImpl("scan");
        var stats = new SortedDictionary<(string impl, string cat), int[]>(); // n, idsEq, countEq, exceptions
        var mism = new StringBuilder();
        var repros = new Dictionary<string, (string impl, string ids, string scanIds, List<string> cases)>();
        long totalCases = 0;
        var sw = Stopwatch.StartNew();
        foreach (var c in ReadCases(casesPath))
        {
            totalCases++;
            foreach (var impl in impls)
            {
                if (impl.Name == "scan-quad" && c.Text.Length > 5000) continue; // quadratic reference scan; bounded
                var key = (impl.Name, c.Cat);
                if (!stats.TryGetValue(key, out var st)) stats[key] = st = new int[4];
                st[0]++;
                IReadOnlyList<int> ids; int count;
                try { ids = impl.Ids(c.Text); count = impl.Count(c.Text); }
                catch (Exception ex)
                {
                    st[3]++;
                    mism.AppendLine($"[{impl.Name}] case={c.Id} cat={c.Cat} EXCEPTION {ex.GetType().Name}: {ex.Message} text={Esc(c.Text, 120)}");
                    continue;
                }
                bool idsEq = ids.SequenceEqual(c.Oracle);
                bool countEq = count == c.Oracle.Length;
                if (idsEq) st[1]++;
                if (countEq) st[2]++;
                if (idsEq && countEq) continue;
                int d = FirstDiff(ids, c.Oracle);
                mism.AppendLine($"[{impl.Name}] case={c.Id} cat={c.Cat} chars={c.Text.Length} oracleCount={c.Oracle.Length} implCount={count} implIdsCount={ids.Count} firstDiff={d} " +
                                $"oracle[{d}..]={Window(c.Oracle, d)} impl[{d}..]={Window(ids, d)} text={Esc(c.Text, 160)}");
                if (reprosPath is not null && impl.Name != "scan" && scan.Ids(c.Text).SequenceEqual(c.Oracle))
                {
                    string min = Minimize(c.Text, t => !SafeIds(impl, t).SequenceEqual(scan.Ids(t)));
                    string k = impl.Name + "\t" + ToHex16(min);
                    if (!repros.TryGetValue(k, out var r))
                        repros[k] = r = (impl.Name, string.Join(",", SafeIds(impl, min)), string.Join(",", scan.Ids(min)), new List<string>());
                    r.cases.Add(c.Id);
                }
            }
        }
        using var w = new StreamWriter(outPath);
        w.WriteLine($"cases={totalCases} impls={string.Join(",", implNames)} elapsed_s={sw.Elapsed.TotalSeconds:F1}");
        w.WriteLine("| impl | category | n | ids equal | count equal | exceptions |");
        w.WriteLine("|---|---|---|---|---|---|");
        foreach (var ((impl, cat), st) in stats) w.WriteLine($"| {impl} | {cat} | {st[0]} | {st[1]} | {st[2]} | {st[3]} |");
        foreach (var name in implNames)
        {
            var tot = stats.Where(kv => kv.Key.impl == name).Select(kv => kv.Value).Aggregate(new int[4], (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2], a[3] + b[3]]);
            w.WriteLine($"TOTAL {name}: n={tot[0]} idsEqual={tot[1]} countEqual={tot[2]} exceptions={tot[3]} mismatches={tot[0] - tot[1]}");
        }
        w.WriteLine("\n## mismatches");
        w.Write(mism);
        if (reprosPath is not null)
            File.WriteAllLines(reprosPath, repros.Select(kv => $"{kv.Value.impl}\t{kv.Key.Split('\t')[1]}\t{kv.Value.ids}\t{kv.Value.scanIds}\t{kv.Value.cases.Count}\t{string.Join(",", kv.Value.cases.Take(5))}"));
        Console.WriteLine(File.ReadAllText(outPath).Split("\n## mismatches")[0]);
        return 0;
    }

    static IReadOnlyList<int> SafeIds(Impl impl, string t)
    {
        try { return impl.Ids(t); } catch (Exception) { return [-1]; }
    }

    // Greedy ddmin over Unicode scalars (a lone surrogate counts as one element): smallest text that still differs.
    static string Minimize(string text, Func<string, bool> stillFails)
    {
        var parts = new List<string>();
        for (int i = 0; i < text.Length;)
        {
            int n = char.IsHighSurrogate(text[i]) && i + 1 < text.Length && char.IsLowSurrogate(text[i + 1]) ? 2 : 1;
            parts.Add(text.Substring(i, n));
            i += n;
        }
        for (int chunk = Math.Max(1, parts.Count / 2); chunk >= 1; chunk = chunk == 1 ? 0 : Math.Max(1, chunk / 2))
        {
            bool progress = true;
            while (progress)
            {
                progress = false;
                for (int start = 0; start < parts.Count;)
                {
                    var candidate = parts.Take(start).Concat(parts.Skip(start + chunk)).ToList();
                    if (candidate.Count > 0 && stillFails(string.Concat(candidate))) { parts = candidate; progress = true; }
                    else start += chunk;
                }
            }
        }
        return string.Concat(parts);
    }

    static int FirstDiff(IReadOnlyList<int> a, IReadOnlyList<int> b)
    {
        int n = Math.Min(a.Count, b.Count);
        for (int i = 0; i < n; i++) if (a[i] != b[i]) return i;
        return n;
    }

    static string Window(IReadOnlyList<int> ids, int from) => "[" + string.Join(",", ids.Skip(from).Take(6)) + (ids.Count > from + 6 ? ",..." : "") + "]";

    static string Esc(string s, int max)
    {
        var sb = new StringBuilder();
        for (int i = 0; i < s.Length && sb.Length < max; i++)
        {
            char ch = s[i];
            if (char.IsHighSurrogate(ch) && i + 1 < s.Length && char.IsLowSurrogate(s[i + 1])) { sb.Append($"\\U{char.ConvertToUtf32(ch, s[i + 1]):X5}"); i++; }
            else if (ch >= 0x20 && ch < 0x7F && ch != '\\') sb.Append(ch);
            else sb.Append($"\\u{(int)ch:X4}");
        }
        if (sb.Length >= max) sb.Append("...");
        return "\"" + sb + "\"";
    }

    static int PrintIds(string impl, string hex)
    {
        var i = MakeImpl(impl);
        string t = FromHex16(hex);
        Console.WriteLine($"{impl} text={Esc(t, 200)} ids=[{string.Join(",", i.Ids(t))}] count={i.Count(t)}");
        return 0;
    }

    // ------------------------------------------------------------------ code point sweep
    // Must match oracle/cpsweep.py TEMPLATES exactly.
    static readonly Func<string, string>[] Templates =
    [
        c => c, c => "a" + c + "b", c => "A" + c + "B", c => " " + c + "!", c => "1" + c + "2", c => c + c + " \n", c => "x'" + c, c => "!" + c + "a",
        c => "123" + c + "456", c => c + "'ll", c => "a" + c + "'ll",
    ];

    static int CpSweep(string sweepPath, string implName, string outPath)
    {
        var impl = MakeImpl(implName);
        var bad = new SortedDictionary<int, List<int>>(); // cp -> failing template indexes
        long n = 0;
        var sw = Stopwatch.StartNew();
        foreach (var line in File.ReadLines(sweepPath))
        {
            int tab = line.IndexOf('\t');
            int cp = Convert.ToInt32(line[..tab], 16);
            string[] expect = line[(tab + 1)..].Split('|');
            string ch = char.ConvertFromUtf32(cp);
            for (int t = 0; t < Templates.Length; t++)
            {
                n++;
                string text = Templates[t](ch);
                IReadOnlyList<int> ids;
                try { ids = impl.Ids(text); } catch (Exception) { ids = [-1]; }
                if (string.Join(",", ids) != expect[t] || impl.Count(text) != (expect[t].Length == 0 ? 0 : expect[t].Count(x => x == ',') + 1))
                {
                    if (!bad.TryGetValue(cp, out var l)) bad[cp] = l = new List<int>();
                    l.Add(t);
                }
            }
        }
        using var w = new StreamWriter(outPath);
        w.WriteLine($"impl={implName} comparisons={n} mismatching_codepoints={bad.Count} elapsed_s={sw.Elapsed.TotalSeconds:F1}");
        // Collapse consecutive code points with the same (failing templates, .NET category) signature into ranges.
        var ranges = new List<(int first, int last, string sig)>();
        foreach (var (cp, ts) in bad)
        {
            string sig = $"dotnetCategory={Abbrev(System.Text.Rune.GetUnicodeCategory(new System.Text.Rune(cp)))} templates={string.Join(",", ts)}";
            if (ranges.Count > 0 && ranges[^1].last == cp - 1 && ranges[^1].sig == sig) ranges[^1] = (ranges[^1].first, cp, sig);
            else ranges.Add((cp, cp, sig));
        }
        foreach (var (first, last, sig) in ranges) w.WriteLine($"U+{first:X4}..U+{last:X4} count={last - first + 1} {sig}");
        w.Flush();
        Console.WriteLine($"impl={implName} comparisons={n} mismatching_codepoints={bad.Count} elapsed_s={sw.Elapsed.TotalSeconds:F1}");
        return 0;
    }

    // ------------------------------------------------------------------ performance
    static (double user, double sys) Cpu()
    {
        using var p = Process.GetCurrentProcess();
        return (p.UserProcessorTime.TotalMilliseconds, p.PrivilegedProcessorTime.TotalMilliseconds);
    }

    static int Bench(string implName, string kind, int len)
    {
        string text = Corpus(kind, len, 0), fresh = Corpus(kind, len, 1);
        var (u0, s0) = Cpu();
        var sw = Stopwatch.StartNew();
        Func<string, int> count;
        BytePairMerger? merger = null;
        if (implName == "ms") { var ms = MsOrdinary(); count = t => ms.CountTokens(t); }
        else
        {
            var c = new O200kCounter(Table(), implName == "regex" ? Segmenter.DotNetRegex : Segmenter.Scalar, 100);
            merger = new BytePairMerger(Table(), 100);
            count = t => c.CountTokens(t, merger);
        }
        double createMs = sw.Elapsed.TotalMilliseconds;
        var (u1, s1) = Cpu();
        var sb = new StringBuilder($"impl={implName} corpus={kind} len={len} create_wall_ms={createMs:F1} create_cpu_ms={(u1 - u0) + (s1 - s0):F1}");
        double slowest = 0;
        foreach (var (label, t) in new[] { ("cold", text), ("warm", text), ("fresh", fresh) })
        {
            long merges0 = merger?.HeapMerges ?? 0;
            var (ua, sa) = Cpu();
            long t0 = Stopwatch.GetTimestamp();
            int r = count(t);
            double wall = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;
            var (ub, sb2) = Cpu();
            sb.Append($" | {label}: count={r} wall_ms={wall:F2} cpu_ms={(ub - ua) + (sb2 - sa):F1}" + (merger is null ? "" : $" heap_merges={merger.HeapMerges - merges0}"));
            slowest = Math.Max(slowest, wall);
            if (wall > 20000) { sb.Append(" | (remaining phases skipped: call > 20 s)"); break; }
        }
        if (slowest > 5000)
        {
            Console.WriteLine(sb.Append(" | steady: skipped (a call > 5 s)").ToString());
            return 0;
        }
        // Steady state (after JIT tiering): repeat the same call up to 200 times within a 3 s budget; report the median.
        var walls = new List<double>(); var cpus = new List<double>();
        var budget = Stopwatch.StartNew();
        while (walls.Count < 200 && budget.ElapsedMilliseconds < 3000)
        {
            var (ua, sa) = Cpu();
            long t0 = Stopwatch.GetTimestamp();
            count(text);
            walls.Add(Stopwatch.GetElapsedTime(t0).TotalMilliseconds);
            var (ub, sb2) = Cpu();
            cpus.Add((ub - ua) + (sb2 - sa));
        }
        walls.Sort(); cpus.Sort();
        sb.Append($" | steady: n={walls.Count} median_wall_ms={walls[walls.Count / 2]:F2} min_wall_ms={walls[0]:F2} median_cpu_ms={cpus[cpus.Count / 2]:F1}");
        var (ue, se) = Cpu();
        sb.Append($" | process_cpu_total_ms={ue + se:F1}");
        Console.WriteLine(sb.ToString());
        return 0;
    }

    static byte[] Piece(string kind, int bytes)
    {
        var rng = new Random(4242);
        var sb = new StringBuilder();
        switch (kind)
        {
            case "cjk": while (sb.Length * 3 < bytes) sb.Append((char)rng.Next(0x4E00, 0xA000)); break;
            case "lower": while (sb.Length < bytes) sb.Append((char)('a' + rng.Next(26))); break;
            case "aaa": sb.Append('a', bytes); break;
            case "punct": { const string p = "!\"#$%&()*+,-./:;<=>?@[]^_`{|}~"; while (sb.Length < bytes) sb.Append(p[rng.Next(p.Length)]); break; }
            default: throw new ArgumentException(kind);
        }
        return Encoding.UTF8.GetBytes(sb.ToString());
    }

    static int BpeBench(string kind, int bytes, string path)
    {
        byte[] piece = Piece(kind, bytes);
        var merger = new BytePairMerger(Table(), path == "heap" ? 0 : int.MaxValue);
        var sb = new StringBuilder($"bpe kind={kind} bytes={piece.Length} path={path}");
        foreach (var label in new[] { "cold", "warm" })
        {
            long m0 = merger.HeapMerges, p0 = merger.HeapPops;
            var (ua, sa) = Cpu();
            long t0 = Stopwatch.GetTimestamp();
            int tokens = merger.Encode(piece, null, CancellationToken.None);
            double wall = Stopwatch.GetElapsedTime(t0).TotalMilliseconds;
            var (ub, sb2) = Cpu();
            double nlogn = piece.Length * Math.Log2(piece.Length);
            sb.Append($" | {label}: tokens={tokens} wall_ms={wall:F2} cpu_ms={(ub - ua) + (sb2 - sa):F1} merges={merger.HeapMerges - m0} pops={merger.HeapPops - p0} ns_per_nlog2n={wall * 1e6 / nlogn:F2}");
        }
        Console.WriteLine(sb.ToString());
        return 0;
    }

    // ------------------------------------------------------------------ cancellation
    static int Cancel(string implName, string kind, int len, int afterMs)
    {
        string text = Corpus(kind, len);
        var counter = new O200kCounter(Table(), implName == "regex" ? Segmenter.DotNetRegex : Segmenter.Scalar, 100);
        long t0 = Stopwatch.GetTimestamp();
        int full = counter.CountTokens(text);
        Console.WriteLine($"cancel impl={implName} corpus={kind} len={len} uncancelled(cold): count={full} wall_ms={Stopwatch.GetElapsedTime(t0).TotalMilliseconds:F2}");
        t0 = Stopwatch.GetTimestamp();
        full = counter.CountTokens(text);
        Console.WriteLine($"  uncancelled(warm): count={full} wall_ms={Stopwatch.GetElapsedTime(t0).TotalMilliseconds:F2}");

        for (int trial = 1; trial <= 5; trial++)
        {
            // (A) CancelAfter + Register timestamp (callback runs on the timer thread inside Cancel()).
            using (var cts = new CancellationTokenSource())
            {
                long signalled = 0;
                cts.Token.Register(() => Volatile.Write(ref signalled, Stopwatch.GetTimestamp()));
                long start = Stopwatch.GetTimestamp();
                cts.CancelAfter(afterMs);
                Report($"A CancelAfter({afterMs}) trial={trial}", counter, text, cts.Token, start, () => Volatile.Read(ref signalled));
            }
            // (B) Dedicated thread: timestamp taken immediately BEFORE cts.Cancel() (upper bound on latency).
            using (var cts = new CancellationTokenSource())
            {
                long requested = 0;
                long start = Stopwatch.GetTimestamp();
                long deadline = start + (long)(afterMs * Stopwatch.Frequency / 1000.0);
                var th = new Thread(() =>
                {
                    while (Stopwatch.GetTimestamp() < deadline) Thread.SpinWait(50);
                    Volatile.Write(ref requested, Stopwatch.GetTimestamp());
                    cts.Cancel();
                });
                th.Start();
                Report($"B thread Cancel() at {afterMs} ms trial={trial}", counter, text, cts.Token, start, () => Volatile.Read(ref requested));
                th.Join();
            }
        }
        return 0;
    }

    static void Report(string label, O200kCounter counter, string text, CancellationToken token, long start, Func<long> signal)
    {
        try
        {
            int r = counter.CountTokens(text, token);
            Console.WriteLine($"  {label}: COMPLETED before cancellation count={r} wall_ms={Stopwatch.GetElapsedTime(start).TotalMilliseconds:F2}");
        }
        catch (OperationCanceledException)
        {
            long stopped = Stopwatch.GetTimestamp();
            long sig = signal();
            Console.WriteLine($"  {label}: OperationCanceledException; signal_at_ms={(sig - start) * 1000.0 / Stopwatch.Frequency:F2} " +
                              $"stopped_at_ms={(stopped - start) * 1000.0 / Stopwatch.Frequency:F2} latency_ms={(stopped - sig) * 1000.0 / Stopwatch.Frequency:F3}");
        }
    }

    // ------------------------------------------------------------------ Unicode data version probe
    static int UnicodeProbe(string agesPath, string outPath)
    {
        // ages.tsv: cpHex \t age \t generalCategory (from Python regex module) for every assigned scalar.
        var byAge = new SortedDictionary<string, int[]>(Comparer<string>.Create((a, b) => Version.Parse(a).CompareTo(Version.Parse(b)))); // total, dotnetAssigned, sameCategory
        var diffs = new List<string>();
        foreach (var line in File.ReadLines(agesPath))
        {
            var f = line.Split('\t');
            int cp = Convert.ToInt32(f[0], 16);
            var cat = System.Text.Rune.GetUnicodeCategory(new System.Text.Rune(cp));
            string dn = Abbrev(cat);
            if (!byAge.TryGetValue(f[1], out var a)) byAge[f[1]] = a = new int[3];
            a[0]++;
            if (dn != "Cn") a[1]++;
            if (dn == f[2]) a[2]++; else if (diffs.Count < 400) diffs.Add($"U+{cp:X4} age={f[1]} pythonRegex={f[2]} dotnet={dn}");
        }
        using var w = new StreamWriter(outPath);
        w.WriteLine($"runtime {RuntimeInformation.FrameworkDescription}");
        w.WriteLine("| age | assigned (python regex) | .NET assigned (not Cn) | same general category |");
        w.WriteLine("|---|---|---|---|");
        foreach (var (age, a) in byAge) w.WriteLine($"| {age} | {a[0]} | {a[1]} | {a[2]} |");
        w.WriteLine("\nfirst category differences:");
        foreach (var d in diffs) w.WriteLine(d);
        w.Flush();
        Console.WriteLine(File.ReadAllText(outPath).Split("\nfirst")[0]);
        return 0;
    }

    static string Abbrev(System.Globalization.UnicodeCategory c) => c switch
    {
        System.Globalization.UnicodeCategory.UppercaseLetter => "Lu", System.Globalization.UnicodeCategory.LowercaseLetter => "Ll",
        System.Globalization.UnicodeCategory.TitlecaseLetter => "Lt", System.Globalization.UnicodeCategory.ModifierLetter => "Lm",
        System.Globalization.UnicodeCategory.OtherLetter => "Lo", System.Globalization.UnicodeCategory.NonSpacingMark => "Mn",
        System.Globalization.UnicodeCategory.SpacingCombiningMark => "Mc", System.Globalization.UnicodeCategory.EnclosingMark => "Me",
        System.Globalization.UnicodeCategory.DecimalDigitNumber => "Nd", System.Globalization.UnicodeCategory.LetterNumber => "Nl",
        System.Globalization.UnicodeCategory.OtherNumber => "No", System.Globalization.UnicodeCategory.SpaceSeparator => "Zs",
        System.Globalization.UnicodeCategory.LineSeparator => "Zl", System.Globalization.UnicodeCategory.ParagraphSeparator => "Zp",
        System.Globalization.UnicodeCategory.Control => "Cc", System.Globalization.UnicodeCategory.Format => "Cf",
        System.Globalization.UnicodeCategory.Surrogate => "Cs", System.Globalization.UnicodeCategory.PrivateUse => "Co",
        System.Globalization.UnicodeCategory.ConnectorPunctuation => "Pc", System.Globalization.UnicodeCategory.DashPunctuation => "Pd",
        System.Globalization.UnicodeCategory.OpenPunctuation => "Ps", System.Globalization.UnicodeCategory.ClosePunctuation => "Pe",
        System.Globalization.UnicodeCategory.InitialQuotePunctuation => "Pi", System.Globalization.UnicodeCategory.FinalQuotePunctuation => "Pf",
        System.Globalization.UnicodeCategory.OtherPunctuation => "Po", System.Globalization.UnicodeCategory.MathSymbol => "Sm",
        System.Globalization.UnicodeCategory.CurrencySymbol => "Sc", System.Globalization.UnicodeCategory.ModifierSymbol => "Sk",
        System.Globalization.UnicodeCategory.OtherSymbol => "So", _ => "Cn",
    };
}
