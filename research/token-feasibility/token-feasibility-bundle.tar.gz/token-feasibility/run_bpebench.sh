#!/usr/bin/env bash
# usage: run_bpebench.sh <outfile>   BPE on ONE synthetic piece per process (timeout 120); heap path to 1 MB, quadratic scan path to 64 KB.
export DOTNET_ROOT=$HOME/dotnet PATH=$HOME/dotnet:$HOME/.dotnet/tools:$HOME/bin:$PATH DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
F=/tmp/claude-0/-home-user-nachos/ce87a920-22b9-5f28-a3e7-d7e10d6d0961/scratchpad/tokinv/feas
H=$F/Harness/bin/Release/net10.0/Harness.dll
out=$1; : > "$out"
TIMEFORMAT='proc_wall_s=%R proc_user_s=%U proc_sys_s=%S'
for kind in cjk lower aaa punct; do
  for n in 1000 4000 16000 64000 256000 1024000; do
    for path in heap scan; do
      if [ $path = scan ] && [ $n -gt 64000 ]; then continue; fi
      line=$( { cd /tmp && time timeout 120 dotnet "$H" bpebench $kind $n $path; echo "exit=$?"; } 2>&1 )
      echo "$(echo "$line" | tr '\n' ' ')" >> "$out"
    done
  done
done
