r"""Infer the NATIVE (tiktoken Rust core) Unicode class tables from encode_ordinary outputs only.

usage: native_unicode.py <cpsweep.tsv> <ages.tsv>
Probe T8 "123"+c+"456": native \p{N}(c)  <=> last token is b"6".
Probe T9 c+"'ll":        native [^\s\p{L}\p{N}](c) (or c==U+0020) <=> last token is b"ll"; letters/marks/N give b"'ll".
Age and general category labels come from DerivedAge 17.0 + the Python `regex` module (labels only).
"""
import collections, sys
import tiktoken
E = tiktoken.get_encoding("o200k_base")
SIX, LL, APLL = E.encode_single_token(b"6"), E.encode_single_token(b"ll"), E.encode_single_token(b"'ll")
ages = {}
for line in open(sys.argv[2]):
    cp, age, gc = line.rstrip("\n").split("\t"); ages[int(cp, 16)] = (age, gc)
tab = collections.defaultdict(lambda: [0, 0, 0])  # (age, gc-group) -> n, nativeN, nativeLetterOrMarkOrN
for line in open(sys.argv[1]):
    cp, rest = line.rstrip("\n").split("\t"); cp = int(cp, 16)
    if cp not in ages: continue
    age, gc = ages[cp]
    if age not in ("15.1", "16.0", "17.0"): continue
    t = rest.split("|")
    t8, t9 = [int(x) for x in t[8].split(",")], [int(x) for x in t[9].split(",")]
    s = tab[(age, gc[0] if gc[0] in "LMN" else "other")]
    s[0] += 1; s[1] += t8[-1] == SIX; s[2] += t9[-1] == APLL
print("| age | gc group (regex-module 17.0 label) | scalars | native treats as \\p{N} | native treats as letter/mark/number (not punct) |")
print("|---|---|---|---|---|")
for k in sorted(tab): print(f"| {k[0]} | {k[1]} | {tab[k][0]} | {tab[k][1]} | {tab[k][2]} |")
for t in ["ʕBc", "ʕB", "AʕBc"]:
    ids = E.encode_ordinary(t); print(f"U+0295 probe {t.encode('unicode_escape').decode()}: ids={ids} pieces={[E.decode_single_token_bytes(i) for i in ids]}")
