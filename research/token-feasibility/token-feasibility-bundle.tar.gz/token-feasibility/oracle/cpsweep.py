"""Oracle ids for every Unicode scalar (U+0000..U+10FFFF minus surrogates) in 11 templates (8 shapes + 3 class probes).

usage: cpsweep.py <out.tsv>      line: cpHex \t ids_t0|...|ids_t10
Templates must match Harness/Program.cs Templates.
"""
import sys

import tiktoken

ENC = tiktoken.get_encoding("o200k_base")
TEMPLATES = [
    lambda c: c, lambda c: "a" + c + "b", lambda c: "A" + c + "B", lambda c: " " + c + "!",
    lambda c: "1" + c + "2", lambda c: c + c + " \n", lambda c: "x'" + c, lambda c: "!" + c + "a",
    # class probes: last token reveals the native class of c
    lambda c: "123" + c + "456",  # last token b"6" iff c in \p{N}, else b"456"
    lambda c: c + "'ll",          # last token b"ll" iff c in [^\s\p{L}\p{N}] (or U+0020); b"'ll" for letters/marks/N/other \s
    lambda c: "a" + c + "'ll",
]


def main():
    with open(sys.argv[1], "w", encoding="ascii") as out:
        for cp in range(0x110000):
            if 0xD800 <= cp <= 0xDFFF:
                continue
            ch = chr(cp)
            out.write(f"{cp:X}\t" + "|".join(",".join(map(str, ENC.encode_ordinary(t(ch)))) for t in TEMPLATES) + "\n")
    print(f"tiktoken {tiktoken.__version__}: wrote {0x110000 - 0x800} code points x {len(TEMPLATES)} templates")


if __name__ == "__main__":
    main()
