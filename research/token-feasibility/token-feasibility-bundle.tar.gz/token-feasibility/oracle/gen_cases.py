"""Generate differential cases + oracle ids (tiktoken o200k_base encode_ordinary).

usage: gen_cases.py <corpora_dir> <out_cases.tsv> [n_random]
line format: id \t category \t utf16le-hex (surrogatepass) \t comma-separated oracle ids
Malformed UTF-16 (lone surrogates) is passed to encode_ordinary as-is: tiktoken's wrapper catches the
UnicodeEncodeError and re-decodes with errors="replace" (U+FFFD per lone surrogate) - see tiktoken/core.py.
"""
import os
import random
import sys
import unicodedata

import tiktoken

ENC = tiktoken.get_encoding("o200k_base")
SEED = 20261008


def r(a, b):
    return [chr(c) for c in range(a, b + 1)]


def cat_filter(chars, prefixes):
    return [c for c in chars if unicodedata.category(c)[:2] in prefixes or unicodedata.category(c)[:1] in prefixes]


ALL_BMP = [chr(c) for c in range(0x10000) if not 0xD800 <= c <= 0xDFFF]
POOLS = {
    "ascii_lower": r(0x61, 0x7A),
    "ascii_upper": r(0x41, 0x5A),
    "ascii_digit": r(0x30, 0x39),
    "ascii_punct": list("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"),
    "ascii_ws": [" ", " ", " ", "\t", "\n", "\r", "\r\n", "\x0b", "\x0c"],
    "unicode_ws": ["\x85", "\xa0", " "] + r(0x2000, 0x200A) + [" ", " ", " ", " ", "　"],
    "not_ws_lookalike": ["\x1c", "\x1d", "\x1e", "\x1f", "᠎", "​", "‌", "‍", "⁠", "﻿"],
    "controls": r(0x00, 0x08) + r(0x0E, 0x1B) + ["\x7f"] + r(0x80, 0x9F),
    "latin_greek_cyrillic": cat_filter(r(0xC0, 0x24F) + r(0x370, 0x3FF) + r(0x400, 0x52F) + r(0x1E00, 0x1EFF), ("L",)),
    "titlecase_Lt": [c for c in ALL_BMP if unicodedata.category(c) == "Lt"],
    "modifier_Lm": [c for c in ALL_BMP if unicodedata.category(c) == "Lm"],
    "marks_M": [c for c in ALL_BMP if unicodedata.category(c)[0] == "M"],
    "cjk_kana_hangul": r(0x4E00, 0x9FFF) + r(0x3041, 0x3096) + r(0x30A1, 0x30FA) + ["ー", "々"] + r(0xAC00, 0xAC00 + 400) + r(0x1100, 0x1112),
    "rtl_indic_thai": cat_filter(r(0x590, 0x6FF) + r(0x900, 0x97F) + r(0xE00, 0xE5B) + r(0xB80, 0xBFF), ("L", "M", "N")),
    "numbers_nonascii": [c for c in ALL_BMP if unicodedata.category(c) in ("Nd", "Nl", "No") and ord(c) > 0x7F],
    "symbols": [c for c in ALL_BMP if unicodedata.category(c) in ("Sm", "Sc", "Sk", "So")],
    "punct_nonascii": [c for c in ALL_BMP if unicodedata.category(c)[0] == "P" and ord(c) > 0x7F],
    "emoji_seq": ["\U0001F600", "\U0001F44D\U0001F3FD", "\U0001F468‍\U0001F469‍\U0001F467‍\U0001F466",
                  "\U0001F3F3️‍\U0001F308", "\U0001F1FA\U0001F1F8", "\U0001F3F4\U000E0067\U000E0062\U000E0065\U000E006E\U000E0067\U000E007F",
                  "1️⃣", "❤️", "☺︎", "\U0001F9D1\U0001F3FF‍\U0001F4BB"] + r(0x1F600, 0x1F64F) + r(0x1F300, 0x1F320),
    "supp_letters": r(0x10400, 0x1044F) + r(0x10330, 0x1034A) + r(0x1D400, 0x1D7CB) + r(0x20000, 0x20100) + r(0x1E900, 0x1E94B) + r(0x104B0, 0x104FB) + r(0x10300, 0x1031F),
    "supp_numbers": r(0x1D7CE, 0x1D7FF) + r(0x104A0, 0x104A9) + r(0x10107, 0x10133) + r(0x1F100, 0x1F10C) + r(0x1D360, 0x1D378) + r(0x11066, 0x1106F),
    "supp_marks": r(0x1D165, 0x1D169) + r(0x1D16D, 0x1D172) + r(0xE0100, 0xE0120) + r(0x11000, 0x11002) + r(0x16AF0, 0x16AF4) + r(0x1E944, 0x1E94A),
    "private_nonchar_unassigned": ["", "", "\U000F0000", "\U0010FFFD", "￾", "￿", "﷐", "͸", "\U0002FFFF", "\U000E0080", "�", "￼"],
    "contractions": ["'s", "'S", "'t", "'T", "'re", "'RE", "'Re", "'rE", "'ve", "'VE", "'m", "'M", "'ll", "'LL", "'lL", "'d", "'D",
                     "'ſ", "'ſs", "’s", "'x", "''s", "'r", "'l", "'v", "'", "'K", "'S'", "n't", "'ll've"],
    "special_spellings": ["<|endoftext|>", "<|endofprompt|>", "<|fim_prefix|>", "<|fim_middle|>", "<|fim_suffix|>", "<|im_start|>",
                          "<|im_end|>", "<|ENDOFTEXT|>", "<| endoftext |>", "<|endoftext", "endoftext|>", "<|"],
    "any_scalar": None,  # uniform over the whole code space (assigned or not), excluding surrogates
    "lone_surrogate": ["\ud800", "\udbff", "\udc00", "\udfff", "\udc00\ud800", "\ud83d"],
}
WEIGHTS = {k: 1.0 for k in POOLS}
WEIGHTS.update(ascii_lower=6, ascii_upper=3, ascii_digit=3, ascii_punct=3, ascii_ws=5, contractions=2, lone_surrogate=0.0)


def any_scalar(rng):
    while True:
        c = rng.randrange(0x110000)
        if not 0xD800 <= c <= 0xDFFF:
            return chr(c)


def fragment(rng, pool_name):
    if pool_name == "any_scalar":
        return any_scalar(rng)
    pool = POOLS[pool_name]
    item = rng.choice(pool)
    if pool_name in ("ascii_lower", "ascii_upper", "cjk_kana_hangul", "latin_greek_cyrillic") and rng.random() < 0.7:
        item = "".join(rng.choice(pool) for _ in range(rng.randint(1, 12)))
    if pool_name == "ascii_ws" and rng.random() < 0.3:
        item = "".join(rng.choice(POOLS["ascii_ws"] + POOLS["unicode_ws"]) for _ in range(rng.randint(2, 60)))
    if pool_name == "ascii_digit" and rng.random() < 0.5:
        item = "".join(rng.choice(pool) for _ in range(rng.randint(1, 10)))
    return item


def random_text(rng, n_frag, malformed):
    names = list(POOLS)
    weights = [WEIGHTS[n] for n in names]
    parts = []
    for _ in range(n_frag):
        name = rng.choices(names, weights)[0]
        parts.append(fragment(rng, name) * (rng.randint(2, 5) if rng.random() < 0.1 else 1))
    if malformed:
        for _ in range(rng.randint(1, 3)):
            parts.insert(rng.randrange(len(parts) + 1), rng.choice(POOLS["lone_surrogate"]))
    return "".join(parts)


def targeted():
    eot = "<|endoftext|>"
    t = [
        ("empty", ""),
        ("eot_x10", eot * 10),
        ("eot_x1", eot),
        ("cedar_A_U10400_B", "A\U00010400B"),
        ("U10400_alone", "\U00010400"),
        ("a_U10428_b", "a\U00010428b"),
        ("math_bold_word", "\U0001D400\U0001D401\U0001D41A\U0001D41B"),
        ("math_digits", "\U0001D7CE\U0001D7CF\U0001D7D0\U0001D7D1"),
        ("cjk_extb", "\U00020000\U00020001abc"),
        ("vs_supp_after_cjk", "葛\U000E0100葛"),
        ("hello_world", "hello world"),
        ("contraction_long_s", "it'ſ"),
        ("contraction_kelvin", "it'K"),
        ("contractions_mixed", "I'M he'S they'Re we'VE you'LL she'D don'T"),
        ("nbsp_word", "a\xa0b \xa0 c"),
        ("u2028", "a b c"),
        ("ideographic_space", "　　abc　"),
        ("ws_then_newline", "   \n\n   x"),
        ("trailing_ws", "abc    "),
        ("crlf_mix", "a\r\n\r\nb\r\r\nc"),
        ("punct_newline_slash", "!\n/x"),
        ("space_punct", " !!! ?? //\n"),
        ("digits_7", "1234567"),
        ("digit_letters", "abc123def4567"),
        ("mark_start", "́abc"),
        ("mark_after_space", " ́́A"),
        ("upper_mark_lower", "Áb"),
        ("titlecase", "ǅungla ǈubljana"),
        ("emoji_zwj", "\U0001F468‍\U0001F469‍\U0001F467 family"),
        ("flag_tags", "\U0001F3F4\U000E0067\U000E0062\U000E0065\U000E006E\U000E0067\U000E007F"),
        ("keycap", "1️⃣ #️⃣"),
        ("mixed_cjk_ascii", "我爱NLP and 日本語123のテスト test."),
        ("lone_high", "\ud800"),
        ("lone_low", "\udc00"),
        ("reversed_pair", "\udc00\ud800"),
        ("lone_in_word", "ab\ud83dcd"),
        ("lone_after_letter_then_letter", "A\ud801B"),
        ("long_ws_run", " " * 5000 + "x"),
        ("long_ws_run_tail", "x" + "\t " * 3000),
        ("long_newlines", "\n" * 4000),
        ("long_digits", "9" * 5001),
        ("long_upper", "A" * 3000 + "b"),
    ]
    for ch in ["a", "A", "1", " ", "\n", "\r", "\t", "'", "!", "é", "中", "\U0001F600", "́", "\U00010400", "\xa0", "\x00", "�"]:
        t.append((f"one_char_U+{ord(ch):04X}", ch))
    for spelling in POOLS["special_spellings"]:
        t.append((f"special_{spelling}", spelling * 3))
    return t


def hex16(s):
    return s.encode("utf-16-le", "surrogatepass").hex()


def main():
    corpora_dir, out_path = sys.argv[1], sys.argv[2]
    n_random = int(sys.argv[3]) if len(sys.argv) > 3 else 30000
    rng = random.Random(SEED)
    rows = []
    for name, text in targeted():
        rows.append((f"t:{name}", "targeted", text))
    for i in range(n_random):
        u = rng.random()
        malformed = rng.random() < 0.03
        if u < 0.80:
            n = rng.randint(1, 25)
            cat = "fuzz_short"
        elif u < 0.97:
            n = rng.randint(25, 250)
            cat = "fuzz_medium"
        else:
            n = rng.randint(500, 3000)
            cat = "fuzz_long"
        rows.append((f"r:{i}", "fuzz_malformed" if malformed else cat, random_text(rng, n, malformed)))
    # 100k-char mixed fuzz inputs
    for i in range(3):
        text = ""
        while len(text) < 100000:
            text += random_text(rng, 200, False)
        rows.append((f"big:{i}", "fuzz_100k", text[:100000] if not "\ud800" <= text[99999] <= "\udbff" else text[:99999]))
    for f in sorted(os.listdir(corpora_dir)):
        with open(os.path.join(corpora_dir, f), encoding="utf-8") as fh:
            rows.append((f"corpus:{f[:-4]}", "corpus", fh.read()))
    with open(out_path, "w", encoding="ascii") as out:
        for cid, cat, text in rows:
            ids = ENC.encode_ordinary(text)
            out.write(f"{cid}\t{cat}\t{hex16(text)}\t{','.join(map(str, ids))}\n")
    by_cat = {}
    for _, cat, _ in rows:
        by_cat[cat] = by_cat.get(cat, 0) + 1
    print(f"tiktoken {tiktoken.__version__} seed={SEED} cases={len(rows)} by_category={by_cat}")
    print(f"check: '<|endoftext|>' x10 encode_ordinary count = {len(ENC.encode_ordinary('<|endoftext|>' * 10))}")


if __name__ == "__main__":
    main()
