"""Summarise out/bench.txt and out/bpebench.txt into markdown. usage: tables.py <feas dir>"""
import math, re, sys
F = sys.argv[1]
def fit(xs, ys):
    lx, ly = [math.log(x) for x in xs], [math.log(y) for y in ys]
    mx, my = sum(lx) / len(lx), sum(ly) / len(ly)
    return sum((a - mx) * (b - my) for a, b in zip(lx, ly)) / sum((a - mx) ** 2 for a in lx)
rows = {}
for line in open(f"{F}/out/bench.txt"):
    h = re.search(r"impl=(\S+) corpus=(\S+) len=(\d+) create_wall_ms=([\d.]+)", line)
    ph = {p: (int(m[1]), float(m[2]), float(m[3])) for p in ("cold", "warm", "fresh") if (m := re.search(p + r": count=(\d+) wall_ms=([\d.]+) cpu_ms=([\d.]+)", line))}
    if (m := re.search(r"steady: n=(\d+) median_wall_ms=([\d.]+) min_wall_ms=[\d.]+ median_cpu_ms=([\d.]+)", line)):
        ph["steady"] = (ph["cold"][0], float(m[2]), float(m[3]), int(m[1]))
    rows[(h[1], h[2], int(h[3]))] = (float(h[4]), ph, re.search(r"exit=(\d+)", line)[1])
L = [1000, 5000, 25000, 100000]
print("### CountTokens wall / CPU ms per call. Default cell = steady-state median (up to 200 repeat calls in a 3 s budget, same process); (w) = 2nd call when steady was skipped because a call took > 5 s; (cold) = 1st call only. One process per cell, timeout 120 s.")
print("| impl | corpus | " + " | ".join(f"{l // 1000}k" for l in L) + " | exponent 1k-100k | exponent 25k-100k | count@100k |")
print("|---|---|" + "---|" * (len(L) + 3))
for impl in ("scan", "regex", "ms"):
    for c in ("C1", "C2", "C3", "C4", "W1", "P1"):
        cells, ys = [], []
        for l in L:
            create, ph, rc = rows[(impl, c, l)]
            p = ph.get("steady") or ph.get("warm") or ph["cold"]
            tag = "" if "steady" in ph else (" (w)" if "warm" in ph else " (cold)")
            ys.append(max(p[1], 1e-3)); cells.append(f"{p[1]:.1f} / {p[2]:.0f}{tag}")
        print(f"| {impl} | {c} | " + " | ".join(cells) + f" | {fit(L, ys):.2f} | {fit(L[2:], ys[2:]):.2f} | {rows[(impl, c, 100000)][1]['cold'][0]} |")
print("\nCold first-call wall ms at 100k (includes JIT): " + "; ".join(f"{i}/{c}={rows[(i, c, 100000)][1]['cold'][1]:.0f}" for i in ("scan", "regex", "ms") for c in ("C1", "W1")))
cw = {i: sorted(v[0] for k, v in rows.items() if k[0] == i) for i in ("scan", "regex", "ms")}
print("Create wall ms (scan/regex = RankTable.Load from the tiktoken file + counter; ms = TiktokenTokenizer.Create from resource), median: " + ", ".join(f"{i} {v[len(v) // 2]:.0f}" for i, v in cw.items()))
print("Counts agree across impls at every cell: " + str(all(rows[("scan", c, l)][1]["cold"][0] == rows[(i, c, l)][1]["cold"][0] for i in ("regex", "ms") for c in ("C1", "C2", "C3", "C4", "W1", "P1") for l in L)))
print("All processes exit=0: " + str(all(v[2] == "0" for v in rows.values())))
print("\n### BPE only, one piece (warm call): wall ms [heap pops per byte]; heap vs tiktoken-style scan")
b = {}
for line in open(f"{F}/out/bpebench.txt"):
    h = re.search(r"kind=(\S+) bytes=(\d+) path=(\S+).*warm: tokens=(\d+) wall_ms=([\d.]+) cpu_ms=([\d.]+) merges=(\d+) pops=(\d+)", line)
    b[(h[1], int(h[2]) // 1000, h[3])] = (int(h[4]), float(h[5]), float(h[6]), int(h[7]), int(h[8]), int(h[2]))
N = [1, 4, 16, 64, 256, 1024]
print("| kind | path | " + " | ".join(f"{n}KB" for n in N) + " | exponent (all sizes) | heap ns/(n log2 n) at 1MB |")
print("|---|---|" + "---|" * (len(N) + 2))
for k in ("cjk", "lower", "aaa", "punct"):
    for p in ("heap", "scan"):
        ns = [n for n in N if (k, n, p) in b]
        cells = [f"{b[(k, n, p)][1]:.1f}" + (f" [{b[(k, n, p)][4] / b[(k, n, p)][5]:.2f}]" if p == "heap" else "") if n in ns else "-" for n in N]
        last = b[(k, 1024, "heap")] if p == "heap" else None
        tail = f"{last[1] * 1e6 / (last[5] * math.log2(last[5])):.1f}" if last else "-"
        print(f"| {k} | {p} | " + " | ".join(cells) + f" | {fit([b[(k, n, p)][5] for n in ns], [b[(k, n, p)][1] for n in ns]):.2f} | {tail} |")
    same = all(b[(k, n, 'heap')][0] == b[(k, n, 'scan')][0] for n in N if (k, n, 'scan') in b)
    print(f"| {k} | heap==scan token count at every size | {same} |" + " |" * (len(N) + 1))
