"""Group regex-variant repros by root cause. usage: classify_repros.py <repros.tsv>"""
import collections, sys
import regex
GC = [(g, regex.compile(r"\p{gc=%s}" % g)) for g in "Lu Ll Lt Lm Lo Mn Mc Me Nd Nl No So Sm Sc Sk Po Ps Pe Pd Cf Co Cn Zs".split()]
def gc(ch): return next((g for g, p in GC if p.match(ch)), "?")
by = collections.Counter(); smallest = {}
for line in open(sys.argv[1], encoding="ascii"):
    impl, hx, *_ = line.split("\t")
    t = bytes.fromhex(hx).decode("utf-16-le", "surrogatepass")
    supp = sorted({gc(c) for c in t if ord(c) > 0xFFFF})
    lone = any(0xD800 <= ord(c) <= 0xDFFF for c in t)
    key = (impl, "supplementary " + "+".join(supp) if supp else ("lone surrogate" if lone else "BMP only: " + " ".join(f"U+{ord(c):04X}/{gc(c)}" for c in t)))
    by[key] += 1
    if key not in smallest or len(t) < len(smallest[key]): smallest[key] = t
for k, n in by.most_common():
    print(f"{k[0]}\t{n}\t{k[1]}\te.g. {smallest[k].encode('unicode_escape').decode()}")
