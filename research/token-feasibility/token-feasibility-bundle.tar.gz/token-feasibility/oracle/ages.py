"""Assigned scalars with their Unicode Age (UCD DerivedAge.txt) and general category from the Python `regex` module.

usage: ages.py <DerivedAge.txt> <out.tsv>     line: cpHex \t age \t gc
Surrogates are skipped (not scalars). Also prints which Unicode version each Python-side table knows.
"""
import sys
import unicodedata

import regex

GCS = ["Lu", "Ll", "Lt", "Lm", "Lo", "Mn", "Mc", "Me", "Nd", "Nl", "No", "Pc", "Pd", "Ps", "Pe", "Pi", "Pf", "Po",
       "Sm", "Sc", "Sk", "So", "Zs", "Zl", "Zp", "Cc", "Cf", "Co", "Cn"]
PATS = [(g, regex.compile(r"\p{gc=%s}" % g)) for g in GCS]


def gc(ch):
    for g, p in PATS:
        if p.match(ch):
            return g
    return "?"


def main():
    ages = {}
    for line in open(sys.argv[1], encoding="utf-8"):
        line = line.split("#")[0].strip()
        if not line:
            continue
        rng, age = [x.strip() for x in line.split(";")]
        a, _, b = rng.partition("..")
        for cp in range(int(a, 16), int(b or a, 16) + 1):
            if not 0xD800 <= cp <= 0xDFFF:
                ages[cp] = age
    per_age = {}
    with open(sys.argv[2], "w", encoding="ascii") as out:
        for cp in sorted(ages):
            g = gc(chr(cp))
            out.write(f"{cp:X}\t{ages[cp]}\t{g}\n")
            s = per_age.setdefault(ages[cp], [0, 0, 0])
            s[0] += 1
            s[1] += g != "Cn"
            s[2] += unicodedata.category(chr(cp)) != "Cn"
    print(f"python unicodedata.unidata_version={unicodedata.unidata_version} regex={regex.__version__}")
    print("| age | assigned (DerivedAge 17.0) | python regex module knows | python unicodedata knows |")
    print("|---|---|---|---|")
    for age in sorted(per_age, key=lambda a: tuple(map(int, a.split(".")))):
        if tuple(map(int, age.split("."))) >= (14, 0):
            print(f"| {age} | {per_age[age][0]} | {per_age[age][1]} | {per_age[age][2]} |")


if __name__ == "__main__":
    main()
