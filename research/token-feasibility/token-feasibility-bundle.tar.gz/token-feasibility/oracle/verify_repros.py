"""Verify minimized repros against the Python oracle.

usage: verify_repros.py <repros.tsv>
repros.tsv line: impl \t utf16hex \t implIds \t scanIds \t nCases \t sampleCaseIds
Confirms oracle(text) == scanIds (prototype scanner agrees with tiktoken) and oracle(text) != implIds.
"""
import sys

import tiktoken

ENC = tiktoken.get_encoding("o200k_base")


def esc(s):
    out = []
    for ch in s:
        o = ord(ch)
        out.append(ch if 0x20 <= o < 0x7F and ch != "\\" else (f"\\u{o:04X}" if o <= 0xFFFF else f"\\U{o:08X}"))
    return '"' + "".join(out) + '"'


def main():
    for line in open(sys.argv[1], encoding="ascii"):
        impl, hx, impl_ids, scan_ids, n, sample = line.rstrip("\n").split("\t")
        text = bytes.fromhex(hx).decode("utf-16-le", "surrogatepass")
        oracle = ",".join(map(str, ENC.encode_ordinary(text)))
        pieces = [ENC.decode_single_token_bytes(t) for t in ENC.encode_ordinary(text)]
        print(f"[{impl}] repro={esc(text)} cases={n} (e.g. {sample})\n    oracle ids=[{oracle}] pieces={pieces}\n"
              f"    {impl} ids=[{impl_ids}]  scan ids=[{scan_ids}]  oracle==scan:{oracle == scan_ids}  oracle!={impl}:{oracle != impl_ids}")


if __name__ == "__main__":
    main()
