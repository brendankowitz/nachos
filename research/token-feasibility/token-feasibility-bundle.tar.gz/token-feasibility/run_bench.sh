#!/usr/bin/env bash
# usage: run_bench.sh <outfile> [impls] [corpora] [lens]   one bounded process (timeout 120) per measurement; sequential.
export DOTNET_ROOT=$HOME/dotnet PATH=$HOME/dotnet:$HOME/.dotnet/tools:$HOME/bin:$PATH DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
F=/tmp/claude-0/-home-user-nachos/ce87a920-22b9-5f28-a3e7-d7e10d6d0961/scratchpad/tokinv/feas
H=$F/Harness/bin/Release/net10.0/Harness.dll
out=$1; : > "$out"
TIMEFORMAT='proc_wall_s=%R proc_user_s=%U proc_sys_s=%S'
for impl in ${2:-scan regex ms}; do
  for c in ${3:-C1 C2 C3 C4 W1 P1}; do
    for len in ${4:-1000 5000 25000 100000}; do
      line=$( { cd /tmp && time timeout 120 dotnet "$H" bench $impl $c $len; echo "exit=$?"; } 2>&1 )
      echo "$(echo "$line" | tr '\n' ' ')" >> "$out"
    done
  done
done
