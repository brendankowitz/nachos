using System.Buffers.Text;

namespace O200k;

/// <summary>
/// Immutable byte-sequence to rank map loaded from a tiktoken BPE file ("base64(token) SP rank" per line).
/// Invariants enforced at load: ranks are exactly 0..Count-1 with no duplicates, tokens are unique,
/// and every single byte 0x00-0xFF has a rank (BPE relies on that to always terminate with known tokens).
/// Thread-safe for concurrent reads after construction.
/// </summary>
public sealed class RankTable
{
    public const int NoRank = int.MaxValue;

    private readonly Dictionary<byte[], int>.AlternateLookup<ReadOnlySpan<byte>> _lookup;

    public int Count { get; }

    /// <summary>Longest token in bytes; lookups of longer spans short-circuit to <see cref="NoRank"/>.</summary>
    public int MaxTokenLength { get; }

    private RankTable(Dictionary<byte[], int> ranks, int maxTokenLength)
    {
        _lookup = ranks.GetAlternateLookup<ReadOnlySpan<byte>>();
        Count = ranks.Count;
        MaxTokenLength = maxTokenLength;
    }

    public int Rank(ReadOnlySpan<byte> bytes) =>
        bytes.Length <= MaxTokenLength && _lookup.TryGetValue(bytes, out int rank) ? rank : NoRank;

    public static RankTable Load(Stream stream)
    {
        using var ms = new MemoryStream();
        stream.CopyTo(ms);
        return Parse(ms.GetBuffer().AsSpan(0, (int)ms.Length));
    }

    private static RankTable Parse(ReadOnlySpan<byte> content)
    {
        var ranks = new Dictionary<byte[], int>(200_000, ByteSequenceComparer.Instance);
        var seenRank = new HashSet<int>();
        int maxLen = 0, lineNo = 0;
        Span<byte> decoded = stackalloc byte[1024];
        foreach (Range lineRange in content.Split((byte)'\n'))
        {
            lineNo++;
            ReadOnlySpan<byte> line = content[lineRange].TrimEnd((byte)'\r');
            if (line.IsEmpty) continue;
            int sp = line.IndexOf((byte)' ');
            if (sp <= 0 || !System.Buffers.Text.Utf8Parser.TryParse(line[(sp + 1)..], out int rank, out int consumed) || consumed != line.Length - sp - 1)
                throw new InvalidDataException($"line {lineNo}: expected '<base64> <rank>'");
            if (Base64.DecodeFromUtf8(line[..sp], decoded, out _, out int written) != System.Buffers.OperationStatus.Done || written == 0)
                throw new InvalidDataException($"line {lineNo}: invalid base64 token");
            if (!ranks.TryAdd(decoded[..written].ToArray(), rank)) throw new InvalidDataException($"line {lineNo}: duplicate token");
            if (!seenRank.Add(rank)) throw new InvalidDataException($"line {lineNo}: duplicate rank {rank}");
            maxLen = Math.Max(maxLen, written);
        }
        for (int r = 0; r < ranks.Count; r++)
            if (!seenRank.Contains(r)) throw new InvalidDataException($"ranks are not dense: {r} missing");
        var table = new RankTable(ranks, maxLen);
        Span<byte> one = stackalloc byte[1];
        for (int b = 0; b < 256; b++)
        {
            one[0] = (byte)b;
            if (table.Rank(one) == NoRank) throw new InvalidDataException($"single byte 0x{b:X2} has no rank");
        }
        return table;
    }

    private sealed class ByteSequenceComparer : IEqualityComparer<byte[]>, IAlternateEqualityComparer<ReadOnlySpan<byte>, byte[]>
    {
        public static readonly ByteSequenceComparer Instance = new();

        public bool Equals(byte[]? x, byte[]? y) => x.AsSpan().SequenceEqual(y);
        public int GetHashCode(byte[] obj) => Hash(obj);
        public bool Equals(ReadOnlySpan<byte> alternate, byte[] other) => alternate.SequenceEqual(other);
        public int GetHashCode(ReadOnlySpan<byte> alternate) => Hash(alternate);
        public byte[] Create(ReadOnlySpan<byte> alternate) => alternate.ToArray();

        private static int Hash(ReadOnlySpan<byte> bytes)
        {
            var h = new HashCode();
            h.AddBytes(bytes);
            return h.ToHashCode();
        }
    }
}
