using System.Buffers;
using System.Text;
using System.Text.RegularExpressions;

namespace O200k;

/// <summary>How text is split into pre-token pieces before BPE.</summary>
public enum Segmenter
{
    /// <summary>Hand-written scanner over Unicode scalars (<see cref="ScalarPreTokenizer"/>).</summary>
    Scalar,

    /// <summary>The o200k pattern copied into System.Text.RegularExpressions, which matches over UTF-16 code units.</summary>
    DotNetRegex,
}

/// <summary>
/// Prototype exact counter for OpenAI o200k_base ORDINARY text (tiktoken encode_ordinary: special-token spellings
/// are plain text). Malformed UTF-16 (lone surrogates) is replaced by U+FFFD per code unit, which is what the
/// tiktoken Python wrapper does before calling its Rust core. Thread-safe: per-call scratch only.
/// Cancellation is cooperative: checked every <see cref="PieceStride"/> pieces and every 1024 heap merges.
/// </summary>
public sealed class O200kCounter
{
    public const string Pattern =
        "[^\\r\\n\\p{L}\\p{N}]?[\\p{Lu}\\p{Lt}\\p{Lm}\\p{Lo}\\p{M}]*[\\p{Ll}\\p{Lm}\\p{Lo}\\p{M}]+(?i:'s|'t|'re|'ve|'m|'ll|'d)?" +
        "|[^\\r\\n\\p{L}\\p{N}]?[\\p{Lu}\\p{Lt}\\p{Lm}\\p{Lo}\\p{M}]+[\\p{Ll}\\p{Lm}\\p{Lo}\\p{M}]*(?i:'s|'t|'re|'ve|'m|'ll|'d)?" +
        "|\\p{N}{1,3}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n/]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+";

    private const int PieceStride = 256;

    private static readonly Regex DotNetPattern = new(Pattern, RegexOptions.Compiled | RegexOptions.CultureInvariant);
    private static readonly UTF8Encoding Utf8Replacing = new(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: false);

    private readonly RankTable _ranks;

    public O200kCounter(RankTable ranks, Segmenter segmenter = Segmenter.Scalar, int heapThreshold = 100)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(heapThreshold);
        _ranks = ranks;
        Segmenter = segmenter;
        HeapThreshold = heapThreshold;
    }

    public Segmenter Segmenter { get; }

    public int HeapThreshold { get; }

    public int CountTokens(string text, CancellationToken cancellationToken = default) =>
        Run(text, ids: null, new BytePairMerger(_ranks, HeapThreshold), cancellationToken);

    public List<int> EncodeToIds(string text, CancellationToken cancellationToken = default)
    {
        var ids = new List<int>();
        Run(text, ids, new BytePairMerger(_ranks, HeapThreshold), cancellationToken);
        return ids;
    }

    /// <summary>Same as <see cref="CountTokens"/> but with a caller-owned merger, for diagnostics (heap counters).</summary>
    public int CountTokens(string text, BytePairMerger merger, CancellationToken cancellationToken = default) =>
        Run(text, ids: null, merger, cancellationToken);

    private int Run(string text, List<int>? ids, BytePairMerger merger, CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();
        return Segmenter == Segmenter.Scalar ? RunScalar(text, ids, merger, ct) : RunRegex(text, ids, merger, ct);
    }

    private static int RunScalar(string text, List<int>? ids, BytePairMerger merger, CancellationToken ct)
    {
        byte[] buffer = ArrayPool<byte>.Shared.Rent(Utf8Replacing.GetMaxByteCount(text.Length));
        try
        {
            int len = Utf8Replacing.GetBytes(text, buffer);
            ReadOnlySpan<byte> utf8 = buffer.AsSpan(0, len);
            int total = 0, pieces = 0;
            for (int p = 0; p < len;)
            {
                if ((++pieces % PieceStride) == 0) ct.ThrowIfCancellationRequested();
                int end = ScalarPreTokenizer.NextEnd(utf8, p);
                total += merger.Encode(utf8[p..end], ids, ct);
                p = end;
            }
            return total;
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    private static int RunRegex(string text, List<int>? ids, BytePairMerger merger, CancellationToken ct)
    {
        byte[] buffer = ArrayPool<byte>.Shared.Rent(256);
        try
        {
            int total = 0, pieces = 0, expected = 0;
            foreach (ValueMatch m in DotNetPattern.EnumerateMatches(text))
            {
                if ((++pieces % PieceStride) == 0) ct.ThrowIfCancellationRequested();
                // tiktoken's find_iter would silently skip unmatched text; surface it instead of dropping tokens.
                if (m.Index != expected) throw new InvalidOperationException($"regex left a gap at UTF-16 index {expected}");
                expected = m.Index + m.Length;
                ReadOnlySpan<char> piece = text.AsSpan(m.Index, m.Length);
                int max = Utf8Replacing.GetMaxByteCount(piece.Length);
                if (max > buffer.Length)
                {
                    ArrayPool<byte>.Shared.Return(buffer);
                    buffer = ArrayPool<byte>.Shared.Rent(max);
                }
                int len = Utf8Replacing.GetBytes(piece, buffer);
                total += merger.Encode(buffer.AsSpan(0, len), ids, ct);
            }
            if (expected != text.Length) throw new InvalidOperationException($"regex left a gap at UTF-16 index {expected}");
            return total;
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }
}
