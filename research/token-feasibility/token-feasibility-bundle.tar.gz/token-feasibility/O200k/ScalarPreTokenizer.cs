using System.Globalization;
using System.Text;

namespace O200k;

/// <summary>
/// Hand-written, scalar-aware equivalent of the o200k_base pre-tokenizer pattern, evaluated over UTF-8 bytes
/// (one Unicode scalar at a time, like tiktoken's Rust fancy-regex over &amp;str):
/// <code>
/// A1 [^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]*[\p{Ll}\p{Lm}\p{Lo}\p{M}]+(?i:'s|'t|'re|'ve|'m|'ll|'d)?
/// A2 [^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]+[\p{Ll}\p{Lm}\p{Lo}\p{M}]*(?i:'s|'t|'re|'ve|'m|'ll|'d)?
/// A3 \p{N}{1,3}
/// A4  ?[^\s\p{L}\p{N}]+[\r\n/]*
/// A5 \s*[\r\n]+
/// A6 \s+(?!\S)
/// A7 \s+
/// </code>
/// Each alternative is resolved to the end position that leftmost-first backtracking would return first
/// (derivations inline). Every scalar is L, N, White_Space or in [^\s\p{L}\p{N}], so some alternative always
/// matches and pieces tile the input with no gaps. Category data comes from the .NET runtime
/// (<see cref="Rune.GetUnicodeCategory"/>); \s is the Unicode White_Space property (as in Rust regex), listed explicitly.
/// </summary>
public static class ScalarPreTokenizer
{
    [Flags]
    private enum Cls : byte
    {
        None = 0,
        Upper = 1,   // [\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]
        Lower = 2,   // [\p{Ll}\p{Lm}\p{Lo}\p{M}]
        Letter = 4,  // \p{L}
        Number = 8,  // \p{N}
        Space = 16,  // \s == White_Space
        CrLf = 32,   // [\r\n]
    }

    private static readonly Cls[] Ascii = BuildAscii();

    /// <summary>Returns the exclusive end (byte offset) of the pre-token that starts at <paramref name="p"/>.</summary>
    public static int NextEnd(ReadOnlySpan<byte> s, int p)
    {
        Cls c0 = At(s, p, out int n0);
        int afterFirst = p + n0;
        // [^\r\n\p{L}\p{N}]? is greedy: try with the optional prefix consumed first, then without.
        bool prefix = (c0 & (Cls.CrLf | Cls.Letter | Cls.Number)) == 0 && afterFirst < s.Length;
        int e;
        if (prefix && (e = UpperStarLowerPlus(s, afterFirst)) >= 0) return Contraction(s, e);
        if ((e = UpperStarLowerPlus(s, p)) >= 0) return Contraction(s, e);
        if (prefix && (e = UpperPlusLowerStar(s, afterFirst)) >= 0) return Contraction(s, e);
        if ((e = UpperPlusLowerStar(s, p)) >= 0) return Contraction(s, e);

        if ((c0 & Cls.Number) != 0) // A3: \p{N}{1,3}
        {
            e = afterFirst;
            for (int k = 1; k < 3 && e < s.Length && (At(s, e, out int n) & Cls.Number) != 0; k++) e += n;
            return e;
        }

        // A4: ' '? is greedy; it only helps when followed by a [^\s\p{L}\p{N}] scalar (' ' itself is \s).
        int q = s[p] == (byte)' ' && afterFirst < s.Length && IsPunct(At(s, afterFirst, out _)) ? afterFirst
              : IsPunct(c0) ? p : -1;
        if (q >= 0)
        {
            while (q < s.Length && IsPunct(At(s, q, out int n))) q += n;
            // [\r\n/]*: '/' is also in Q, but it can still follow a CR/LF here (e.g. "!\n/").
            while (q < s.Length && s[q] is (byte)'\r' or (byte)'\n' or (byte)'/') q++;
            return q;
        }

        if ((c0 & Cls.Space) == 0) throw new InvalidOperationException($"unclassified scalar at byte {p}"); // unreachable

        // A5-A7 over the maximal White_Space run [p, r).
        int pos = p, lastStart = p, lastCrLfEnd = -1;
        while (pos < s.Length)
        {
            Cls c = At(s, pos, out int n);
            if ((c & Cls.Space) == 0) break;
            lastStart = pos;
            pos += n;
            if ((c & Cls.CrLf) != 0) lastCrLfEnd = pos;
        }
        // A5: \s* gives back scalars from the right until [\r\n]+ can start: ends right after the LAST CR/LF in the run.
        if (lastCrLfEnd >= 0) return lastCrLfEnd;
        // A6: the whole run if it reaches end of text; else the run minus its last scalar if that leaves >= 1 scalar.
        if (pos == s.Length) return pos;
        if (lastStart > p) return lastStart;
        // A7: a single White_Space scalar followed by non-space.
        return pos;
    }

    // [U]*[W]+ at q. Greedy U* takes the maximal U run [q, r). If s[r] is W, W+ takes the maximal W run from r.
    // Otherwise U* backtracks one scalar at a time; W+ first succeeds at the last W scalar inside the run and
    // (since the following scalar is not W) consumes exactly that scalar. No W anywhere: fail.
    private static int UpperStarLowerPlus(ReadOnlySpan<byte> s, int q)
    {
        int pos = q, lastLowerEnd = -1;
        while (pos < s.Length)
        {
            Cls c = At(s, pos, out int n);
            if ((c & Cls.Upper) == 0) break;
            pos += n;
            if ((c & Cls.Lower) != 0) lastLowerEnd = pos;
        }
        if (pos < s.Length && (At(s, pos, out _) & Cls.Lower) != 0)
        {
            while (pos < s.Length && (At(s, pos, out int n) & Cls.Lower) != 0) pos += n;
            return pos;
        }
        return lastLowerEnd;
    }

    // [U]+[W]* at q: maximal U run (>= 1), then maximal W run; W* cannot fail.
    private static int UpperPlusLowerStar(ReadOnlySpan<byte> s, int q)
    {
        if (q >= s.Length || (At(s, q, out _) & Cls.Upper) == 0) return -1;
        int pos = q;
        while (pos < s.Length && (At(s, pos, out int n) & Cls.Upper) != 0) pos += n;
        while (pos < s.Length && (At(s, pos, out int n) & Cls.Lower) != 0) pos += n;
        return pos;
    }

    // (?i:'s|'t|'re|'ve|'m|'ll|'d)? with Unicode simple case folding (Rust regex): s also matches U+017F LATIN SMALL
    // LETTER LONG S. No other scalar folds to t, r, e, v, m, l or d.
    private static int Contraction(ReadOnlySpan<byte> s, int e)
    {
        if (e + 1 >= s.Length || s[e] != (byte)'\'') return e;
        byte a = (byte)(s[e + 1] | 0x20);
        bool hasThird = e + 2 < s.Length;
        byte b = hasThird ? (byte)(s[e + 2] | 0x20) : (byte)0;
        if (s[e + 1] < 0x80)
        {
            switch (a)
            {
                case (byte)'s' or (byte)'t' or (byte)'m' or (byte)'d': return e + 2;
                case (byte)'r' or (byte)'v' when b == (byte)'e' && s[e + 2] < 0x80: return e + 3;
                case (byte)'l' when b == (byte)'l' && s[e + 2] < 0x80: return e + 3;
            }
            return e;
        }
        return hasThird && s[e + 1] == 0xC5 && s[e + 2] == 0xBF ? e + 3 : e; // 'ſ
    }

    private static bool IsPunct(Cls c) => (c & (Cls.Space | Cls.Letter | Cls.Number)) == 0; // [^\s\p{L}\p{N}]

    private static Cls At(ReadOnlySpan<byte> s, int i, out int length)
    {
        byte b = s[i];
        if (b < 0x80)
        {
            length = 1;
            return Ascii[b];
        }
        // Input is produced by a replacing UTF-8 encoder, so it is well-formed; a malformed sequence would decode as U+FFFD.
        Rune.DecodeFromUtf8(s[i..], out Rune r, out length);
        return Classify(r);
    }

    private static Cls Classify(Rune r)
    {
        if (IsWhiteSpaceProperty(r.Value)) return r.Value is '\r' or '\n' ? Cls.Space | Cls.CrLf : Cls.Space;
        return Rune.GetUnicodeCategory(r) switch
        {
            UnicodeCategory.UppercaseLetter or UnicodeCategory.TitlecaseLetter => Cls.Upper | Cls.Letter,
            UnicodeCategory.LowercaseLetter => Cls.Lower | Cls.Letter,
            UnicodeCategory.ModifierLetter or UnicodeCategory.OtherLetter => Cls.Upper | Cls.Lower | Cls.Letter,
            UnicodeCategory.NonSpacingMark or UnicodeCategory.SpacingCombiningMark or UnicodeCategory.EnclosingMark => Cls.Upper | Cls.Lower,
            UnicodeCategory.DecimalDigitNumber or UnicodeCategory.LetterNumber or UnicodeCategory.OtherNumber => Cls.Number,
            _ => Cls.None,
        };
    }

    // Unicode White_Space property (PropList.txt, unchanged since Unicode 6.3 removed U+180E).
    private static bool IsWhiteSpaceProperty(int v) => v switch
    {
        >= 0x09 and <= 0x0D or 0x20 or 0x85 or 0xA0 or 0x1680 or (>= 0x2000 and <= 0x200A)
            or 0x2028 or 0x2029 or 0x202F or 0x205F or 0x3000 => true,
        _ => false,
    };

    private static Cls[] BuildAscii()
    {
        var t = new Cls[128];
        for (int i = 0; i < 128; i++) t[i] = Classify(new Rune(i));
        return t;
    }
}
