namespace O200k;

/// <summary>
/// tiktoken-equivalent byte-pair merge of one pre-token piece.
/// Merge rule (tiktoken CoreBPE::_byte_pair_merge): repeatedly merge the adjacent part pair whose concatenation
/// has the lowest rank; ties go to the leftmost pair; stop when no adjacent pair concatenation has a rank.
/// Before merging, a piece that is itself a vocabulary entry is emitted as one token (tiktoken does this lookup
/// first, and it is NOT implied by the merge rule).
/// Pieces shorter than <see cref="HeapThreshold"/> bytes use tiktoken's own O(n*m) scan; longer pieces use a
/// binary-heap ordered by (rank, left offset) with per-node generations for stale-entry detection: O(n log n).
/// Not thread-safe: owns reusable scratch buffers; create one per concurrent call.
/// </summary>
public sealed class BytePairMerger
{
    private const int CancellationStride = 1024;

    private readonly RankTable _ranks;
    private readonly PriorityQueue<(int Node, int Gen), long> _heap = new();
    private int[] _next = [];
    private int[] _prev = [];
    private int[] _gen = [];

    public BytePairMerger(RankTable ranks, int heapThreshold)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(heapThreshold);
        _ranks = ranks;
        HeapThreshold = heapThreshold;
    }

    public int HeapThreshold { get; }

    /// <summary>Total merges performed by the heap path since construction (diagnostics for complexity evidence).</summary>
    public long HeapMerges { get; private set; }

    /// <summary>Total heap pops (valid + stale) since construction.</summary>
    public long HeapPops { get; private set; }

    /// <summary>Returns the number of tokens for <paramref name="piece"/>; appends their ids to <paramref name="ids"/> when non-null.</summary>
    public int Encode(ReadOnlySpan<byte> piece, List<int>? ids, CancellationToken ct)
    {
        int whole = _ranks.Rank(piece);
        if (whole != RankTable.NoRank)
        {
            ids?.Add(whole);
            return 1;
        }
        return piece.Length < HeapThreshold ? EncodeScan(piece, ids) : EncodeHeap(piece, ids, ct);
    }

    // Direct transcription of tiktoken's _byte_pair_merge. Heap-allocates only when a test raises HeapThreshold.
    private int EncodeScan(ReadOnlySpan<byte> piece, List<int>? ids)
    {
        int n = piece.Length;
        Span<int> start = n < 256 ? stackalloc int[n + 1] : new int[n + 1];
        Span<int> rank = n < 256 ? stackalloc int[n + 1] : new int[n + 1];
        for (int i = 0; i < n; i++)
        {
            start[i] = i;
            rank[i] = i + 2 <= n ? _ranks.Rank(piece.Slice(i, 2)) : RankTable.NoRank;
        }
        start[n] = n;
        rank[n] = RankTable.NoRank;
        int count = n + 1; // parts incl. the end sentinel

        while (true)
        {
            int minRank = RankTable.NoRank, at = -1;
            for (int i = 0; i < count - 1; i++)
                if (rank[i] < minRank) { minRank = rank[i]; at = i; }
            if (at < 0) break;

            // remove part at+1 (merging it into part at)
            start.Slice(at + 2, count - at - 2).CopyTo(start.Slice(at + 1));
            rank.Slice(at + 2, count - at - 2).CopyTo(rank.Slice(at + 1));
            count--;
            rank[at] = at + 2 < count ? _ranks.Rank(piece[start[at]..start[at + 2]]) : RankTable.NoRank;
            if (at > 0) rank[at - 1] = _ranks.Rank(piece[start[at - 1]..start[at + 1]]);
        }

        if (ids is not null)
            for (int i = 0; i < count - 1; i++) ids.Add(TokenRank(piece[start[i]..start[i + 1]]));
        return count - 1;
    }

    // Nodes are identified by their start byte offset (a merge keeps the left node), so node order == offset order and
    // the heap priority (rank << 32 | node) realises "lowest rank, then leftmost" exactly.
    private int EncodeHeap(ReadOnlySpan<byte> piece, List<int>? ids, CancellationToken ct)
    {
        int n = piece.Length;
        EnsureCapacity(n);
        int[] next = _next, prev = _prev, gen = _gen;
        var heap = _heap;
        heap.Clear();
        for (int i = 0; i < n; i++)
        {
            next[i] = i + 1;
            prev[i] = i - 1;
            gen[i] = 0;
        }
        for (int i = 0; i + 1 < n; i++)
        {
            int r = _ranks.Rank(piece.Slice(i, 2));
            if (r != RankTable.NoRank) heap.Enqueue((i, 0), Priority(r, i));
        }

        int live = n;
        long steps = 0;
        while (heap.TryDequeue(out var entry, out _))
        {
            HeapPops++;
            if ((++steps % CancellationStride) == 0) ct.ThrowIfCancellationRequested();
            int node = entry.Node;
            if (gen[node] != entry.Gen) continue; // stale: node died, grew, or its right neighbour grew

            int right = next[node];
            int after = next[right]; // <= n
            next[node] = after;
            if (after < n) prev[after] = node;
            gen[right]++; // dead
            gen[node]++;
            live--;
            HeapMerges++;

            if (after < n)
            {
                int r = _ranks.Rank(piece[node..next[after]]);
                if (r != RankTable.NoRank) heap.Enqueue((node, gen[node]), Priority(r, node));
            }
            int left = prev[node];
            if (left >= 0)
            {
                gen[left]++;
                int r = _ranks.Rank(piece[left..after]);
                if (r != RankTable.NoRank) heap.Enqueue((left, gen[left]), Priority(r, left));
            }
        }

        if (ids is not null)
            for (int i = 0; i < n; i = next[i]) ids.Add(TokenRank(piece[i..next[i]]));
        return live;
    }

    private int TokenRank(ReadOnlySpan<byte> token)
    {
        int r = _ranks.Rank(token);
        // Unreachable for a table that contains every single byte: every final part is a byte or a merge result.
        if (r == RankTable.NoRank) throw new InvalidOperationException("BPE produced a part with no rank");
        return r;
    }

    private static long Priority(int rank, int node) => ((long)rank << 32) | (uint)node;

    private void EnsureCapacity(int n)
    {
        if (_next.Length >= n) return;
        int size = Math.Max(n, _next.Length * 2);
        _next = new int[size];
        _prev = new int[size];
        _gen = new int[size];
    }
}
